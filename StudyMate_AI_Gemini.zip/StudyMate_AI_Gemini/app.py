import os
import streamlit as st
from google import genai
from google.genai import types

st.set_page_config(
    page_title="StudyMate AI",
    page_icon="🎓",
    layout="wide"
)

# ---------- Styling ----------
st.markdown("""
<style>
.main-title {
    font-size: 2.6rem;
    font-weight: 800;
    margin-bottom: 0.2rem;
}
.subtitle {
    font-size: 1.05rem;
    color: #666;
    margin-bottom: 1.5rem;
}
.result-box {
    padding: 1.2rem 1.4rem;
    border: 1px solid #ddd;
    border-radius: 14px;
    background: rgba(250,250,250,0.7);
}
</style>
""", unsafe_allow_html=True)

st.markdown(
    '<div class="main-title">🎓 StudyMate AI</div>',
    unsafe_allow_html=True
)
st.markdown(
    '<div class="subtitle">Your AI-powered study companion for summarizing, quizzes, better answers, and simple explanations.</div>',
    unsafe_allow_html=True
)

# ---------- API configuration ----------
gemini_api_key = None

try:
    gemini_api_key = st.secrets.get("GEMINI_API_KEY")
except Exception:
    pass

gemini_api_key = gemini_api_key or os.getenv("GEMINI_API_KEY")

with st.sidebar:
    st.header("⚙️ Settings")

    feature = st.radio(
        "Choose a study utility",
        [
            "📝 Summarize Notes",
            "❓ Generate Quiz",
            "✍️ Improve Answer",
            "💡 Explain Concept"
        ]
    )

    model = st.selectbox(
        "Gemini Model",
        ["gemini-2.5-flash", "gemini-2.5-flash-lite"],
        index=0
    )

    st.divider()
    st.caption(
        "API key is read from Streamlit Secrets or the GEMINI_API_KEY environment variable."
    )

# ---------- Prompt design ----------
def build_prompt(feature_name, content):
    prompts = {
        "📝 Summarize Notes": f"""
You are StudyMate AI, a helpful academic study assistant.

TASK:
Create a concise study summary from the material below.

OUTPUT REQUIREMENTS:
- Start with a clear title.
- Give 5-10 key points using bullet points.
- Preserve important definitions, facts, formulas, and relationships.
- Use simple student-friendly language.
- End with a "Quick Revision" section containing 3 essential takeaways.
- Do not add facts that are not supported by the provided material.

STUDY MATERIAL:
{content}
""",

        "❓ Generate Quiz": f"""
You are StudyMate AI, a quiz-generation assistant.

TASK:
Create a short practice quiz based only on the study material below.

OUTPUT REQUIREMENTS:
- Generate 5 multiple-choice questions.
- Give 4 options (A-D) for each question.
- Clearly mark the correct answer after each question.
- Add a one-sentence explanation for each answer.
- Questions should test understanding, not just word matching.
- Do not use information outside the supplied material.

STUDY MATERIAL:
{content}
""",

        "✍️ Improve Answer": f"""
You are StudyMate AI, an academic writing assistant.

TASK:
Improve the student's answer below while preserving its original meaning.

OUTPUT REQUIREMENTS:
1. Improved Answer
2. What Was Improved (3-5 bullets)
3. One Tip for the Student

Make the answer clear, accurate, well-structured, and student-friendly.
Do not invent unsupported facts.

STUDENT ANSWER:
{content}
""",

        "💡 Explain Concept": f"""
You are StudyMate AI, a patient teacher.

TASK:
Explain the student's topic or question in a way that is easy for a student to understand.

OUTPUT REQUIREMENTS:
- Give a simple definition first.
- Explain the idea step by step.
- Include a simple real-world example or analogy.
- List 3 key points to remember.
- If the input is a question, answer it directly before the explanation.
- Avoid unnecessary jargon.

TOPIC / QUESTION:
{content}
"""
    }

    return prompts[feature_name]


placeholder = {
    "📝 Summarize Notes":
        "Paste your class notes, textbook content, or study material here...",
    "❓ Generate Quiz":
        "Paste notes or study material from which you want to create a quiz...",
    "✍️ Improve Answer":
        "Paste your answer here and StudyMate AI will improve it...",
    "💡 Explain Concept":
        "Enter a difficult concept or question you want explained..."
}[feature]

content = st.text_area(
    "📚 Your Content",
    height=260,
    placeholder=placeholder,
    help="Enter enough context for the AI to produce a useful result."
)

if st.button("✨ Generate", type="primary", use_container_width=False):
    cleaned = content.strip()

    # ---------- Input validation ----------
    if not cleaned:
        st.warning(
            "Please enter some notes, a question, or an answer before generating."
        )
        st.stop()

    if len(cleaned) < 10:
        st.warning(
            "Please provide a little more content (at least 10 characters)."
        )
        st.stop()

    # ---------- API key validation ----------
    if not gemini_api_key:
        st.error(
            "Gemini API key is not configured. Add GEMINI_API_KEY to "
            ".streamlit/secrets.toml or set it as an environment variable."
        )
        st.info(
            "Example: GEMINI_API_KEY = \"your_key_here\""
        )
        st.stop()

    try:
        client = genai.Client(api_key=gemini_api_key)
        prompt = build_prompt(feature, cleaned)

        with st.spinner("🤖 StudyMate AI is thinking..."):
            response = client.models.generate_content(
                model=model,
                contents=prompt,
                config=types.GenerateContentConfig(
                    system_instruction=(
                        "You are StudyMate AI. Follow the requested output "
                        "structure exactly. Be clear, accurate, and concise."
                    ),
                    temperature=0.4,
                    max_output_tokens=1500
                )
            )

        answer = response.text if response else ""

        if not answer or not answer.strip():
            st.error(
                "The AI returned an empty response. Please try again."
            )
        else:
            st.subheader("✨ AI Generated Result")
            st.markdown('<div class="result-box">', unsafe_allow_html=True)
            st.markdown(answer)
            st.markdown('</div>', unsafe_allow_html=True)

    except Exception as e:
        st.error(
            "Something went wrong while contacting the Gemini AI service."
        )

        error_text = str(e)

        if "429" in error_text or "quota" in error_text.lower():
            st.warning(
                "The Gemini API free-tier limit may have been reached. "
                "Wait for the quota to reset or try again later."
            )

        with st.expander("Technical details"):
            st.code(error_text)

st.divider()

st.caption(
    "StudyMate AI • Beginner AI Engineer Internship Project • "
    "Built with Streamlit + Google Gemini API"
)
